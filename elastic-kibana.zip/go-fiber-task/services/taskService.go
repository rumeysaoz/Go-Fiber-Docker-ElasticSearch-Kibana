package services

import (
    "bytes"
    "context"
    "encoding/json"
    "fmt"
    "github.com/elastic/go-elasticsearch/v7"
    "go-fiber-task/models" 
    "log"
//    "net/http"
//    "strconv"
    "sync/atomic"
    "time"
)

var taskID int64

// CreateTask, bir task'ı ElasticSearch'e kaydeder.
func CreateTask(es *elasticsearch.Client, task *models.Task) error {
    newID := atomic.AddInt64(&taskID, 1)
    task.ID = fmt.Sprintf("%d", newID)
    task.CreationTime = time.Now()

    jsonTask, err := json.Marshal(task)
    if err != nil {
        return err
    }

    res, err := es.Index("tasks", bytes.NewReader(jsonTask), es.Index.WithDocumentID(task.ID), es.Index.WithRefresh("true"))
    if err != nil || res.IsError() {
        return fmt.Errorf("error indexing task: %s", res.String())
    }
    return nil
}

// GetAllTasks, ElasticSearch'teki tüm task'ları listeler.
func GetAllTasks(es *elasticsearch.Client) ([]models.Task, error) {
    var r map[string]interface{}
    res, err := es.Search(
        es.Search.WithContext(context.Background()),
        es.Search.WithIndex("tasks"),
        es.Search.WithSize(1000), // Maksimum 1000 task getir
    )
    if err != nil || res.IsError() {
        return nil, fmt.Errorf("error getting tasks: %s", res.String())
    }
    defer res.Body.Close()

    if err := json.NewDecoder(res.Body).Decode(&r); err != nil {
        return nil, err
    }

    hits := r["hits"].(map[string]interface{})["hits"].([]interface{})
    tasks := make([]models.Task, len(hits))

    for i, hit := range hits {
        source := hit.(map[string]interface{})["_source"]
        sourceBytes, _ := json.Marshal(source)
        var task models.Task
        if err := json.Unmarshal(sourceBytes, &task); err != nil {
            log.Printf("Failed to unmarshal source: %v", err)
            continue
        }
        tasks[i] = task
    }

    return tasks, nil
}

// UpdateTask, belirli bir ID'ye sahip task'ı günceller.
func UpdateTask(es *elasticsearch.Client, id string, taskUpdates models.Task) error {
    // Sadece güncellenmek istenen alanları belirleyin.
    // Örneğin: 'header' ve 'description' alanlarını güncellemek istiyoruz.
    updateDoc := map[string]interface{}{
        "doc": map[string]interface{}{
            "header":      taskUpdates.Header,
            "description": taskUpdates.Description,
        },
    }

    // Güncelleme için JSON'a dönüştür
    reqBody, err := json.Marshal(updateDoc)
    if err != nil {
        return err
    }

    // Elasticsearch güncelleme API'sini kullanarak güncelleme işlemini yapın
    res, err := es.Update(
        "tasks", // Index adı
        id,      // Güncellenecek dokümanın ID'si
        bytes.NewReader(reqBody), // Güncelleme için JSON içeriği
        es.Update.WithContext(context.Background()),
        es.Update.WithRefresh("true"), // Güncelleme sonrası index'i yenile
    )
    if err != nil || res.IsError() {
        return fmt.Errorf("error updating task: %s", res.String())
    }
    return nil
}

// DeleteTask, belirli bir ID'ye sahip task'ı siler.
func DeleteTask(es *elasticsearch.Client, id string) error {
    res, err := es.Delete("tasks", id, es.Delete.WithRefresh("true"))
    if err != nil || res.IsError() {
        return fmt.Errorf("error deleting task: %s", res.String())
    }
    return nil
}
