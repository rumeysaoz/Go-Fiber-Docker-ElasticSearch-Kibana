package models

import "time"

// Task yapısını tanımla. Bir Task, bir ID, başlık, açıklama ve oluşturulma zamanını içerir.
type Task struct {
    ID          string    `json:"id"`
    Header      string    `json:"header"`
    Description string    `json:"description"`
    CreationTime time.Time `json:"creation_time"`
}
