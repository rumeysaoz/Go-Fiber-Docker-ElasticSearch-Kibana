package main

import (
    "github.com/gofiber/fiber/v2"
    "go-fiber-task/handlers"
    "github.com/elastic/go-elasticsearch/v7"
    "log"
)

func main() {
    es, err := elasticsearch.NewDefaultClient()
    if err != nil {
        log.Fatalf("Error creating the client: %s", err)
    }

    app := fiber.New()
    handlers.RegisterTaskRoutes(app, es)

    log.Fatal(app.Listen(":3000"))
}
