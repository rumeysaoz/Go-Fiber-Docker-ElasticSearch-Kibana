package handlers

import (
    "github.com/gofiber/fiber/v2"
    "go-fiber-task/models"
    "go-fiber-task/services"
    "github.com/elastic/go-elasticsearch/v7"
    "net/http"
//    "strconv"
)

func RegisterTaskRoutes(app *fiber.App, es *elasticsearch.Client) {
    app.Post("/task", func(c *fiber.Ctx) error {
        var task models.Task
        if err := c.BodyParser(&task); err != nil {
            return c.Status(fiber.StatusBadRequest).SendString(err.Error())
        }

        if err := services.CreateTask(es, &task); err != nil {
            return c.Status(http.StatusInternalServerError).SendString(err.Error())
        }

        return c.Status(fiber.StatusOK).JSON(task)
    })

    app.Get("/tasks", func(c *fiber.Ctx) error {
        tasks, err := services.GetAllTasks(es)
        if err != nil {
            return c.Status(http.StatusInternalServerError).SendString(err.Error())
        }

        return c.Status(fiber.StatusOK).JSON(tasks)
    })

    app.Put("/task/:id", func(c *fiber.Ctx) error {
        id := c.Params("id")
        var taskUpdates models.Task
        if err := c.BodyParser(&taskUpdates); err != nil {
            return c.Status(fiber.StatusBadRequest).SendString(err.Error())
        }

        if err := services.UpdateTask(es, id, taskUpdates); err != nil {
            return c.Status(http.StatusInternalServerError).SendString(err.Error())
        }

        return c.SendStatus(fiber.StatusOK)
    })

    app.Delete("/task/:id", func(c *fiber.Ctx) error {
        id := c.Params("id")

        if err := services.DeleteTask(es, id); err != nil {
            return c.Status(http.StatusInternalServerError).SendString(err.Error())
        }

        return c.SendStatus(fiber.StatusOK)
    })
}
