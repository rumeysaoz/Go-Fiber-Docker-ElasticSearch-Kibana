package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
//	"net/http"
//	"os"
	"time"

	"github.com/go-redis/redis/v8"
	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v4"
)

// Task modeli
type Task struct {
	ID           int64     `json:"id"`
	Header       string    `json:"header"`
	Description  string    `json:"description"`
	CreationTime time.Time `json:"creation_time"`
}

var pgConn *pgx.Conn
var redisClient *redis.Client

func initPostgres() {
	var err error
	pgConn, err = pgx.Connect(context.Background(), "postgres://postgres:postgres@localhost:5432/taskdb")
	if err != nil {
		log.Fatalf("Unable to connect to PostgreSQL: %v", err)
	}
	fmt.Println("Connected to PostgreSQL")

	// Tasks tablosunu oluştur
	_, err = pgConn.Exec(context.Background(), `
		CREATE TABLE IF NOT EXISTS tasks (
			id SERIAL PRIMARY KEY,
			header VARCHAR(255) NOT NULL,
			description TEXT,
			creation_time TIMESTAMP NOT NULL
		)
	`)
	if err != nil {
		log.Fatalf("Unable to create tasks table: %v", err)
	}
	fmt.Println("Tasks table created")
}

func initRedis() {
	redisClient = redis.NewClient(&redis.Options{
		Addr:     "localhost:6379",
		Password: "", // no password set
		DB:       0,  // use default DB
	})

	_, err := redisClient.Ping(context.Background()).Result()
	if err != nil {
		log.Fatalf("Unable to connect to Redis: %v", err)
	}
	fmt.Println("Connected to Redis")
}

func createTask(c *fiber.Ctx) error {
	task := new(Task)

	if err := c.BodyParser(task); err != nil {
		return c.Status(400).SendString(err.Error())
	}

	task.CreationTime = time.Now()

	_, err := pgConn.Exec(context.Background(), "INSERT INTO tasks (header, description, creation_time) VALUES ($1, $2, $3)", task.Header, task.Description, task.CreationTime)
	if err != nil {
		return c.Status(500).SendString(err.Error())
	}

	return c.Status(201).JSON(task)
}

func getTask(c *fiber.Ctx) error {
	id := c.Params("id")
	ctx := context.Background()

	// Öncelikle Redis'te arayalım
	val, err := redisClient.Get(ctx, id).Result()
	if err == nil {
		// Cache'te bulundu
		task := new(Task)
		if err := json.Unmarshal([]byte(val), task); err != nil {
			return c.Status(500).SendString(err.Error())
		}
		return c.JSON(task)
	}

	// Redis'te bulunamazsa, PostgreSQL'den arayalım
	task := new(Task)
	err = pgConn.QueryRow(ctx, "SELECT id, header, description, creation_time FROM tasks WHERE id = $1", id).Scan(&task.ID, &task.Header, &task.Description, &task.CreationTime)
	if err != nil {
		return c.Status(404).SendString("Task not found")
	}

	// Sonucu Redis'e kaydedelim
	jsonData, err := json.Marshal(task)
	if err != nil {
		return c.Status(500).SendString(err.Error())
	}
	redisClient.Set(ctx, fmt.Sprintf("%d", task.ID), string(jsonData), 30*time.Minute) // 30 dakika boyunca cache'le

	return c.JSON(task) // Fonksiyonun sonunda başarıyla Task'ı JSON olarak döndür
}

func updateTask(c *fiber.Ctx) error {
	id := c.Params("id")
	task := new(Task)

	if err := c.BodyParser(task); err != nil {
		return c.Status(400).SendString(err.Error())
	}

	// Veritabanında güncelleme işlemi yapılacak
	ctx := context.Background()
	_, err := pgConn.Exec(ctx, "UPDATE tasks SET header = $1, description = $2 WHERE id = $3", task.Header, task.Description, id)
	if err != nil {
		return c.Status(500).SendString(err.Error())
	}

	// Güncelleme başarılı oldu, HTTP 200 OK dön
	return c.SendStatus(fiber.StatusOK)
}

func deleteTask(c *fiber.Ctx) error {
	id := c.Params("id")

	// Veritabanında silme işlemi yapılacak
	ctx := context.Background()
	_, err := pgConn.Exec(ctx, "DELETE FROM tasks WHERE id = $1", id)
	if err != nil {
		return c.Status(500).SendString(err.Error())
	}

	// Silme başarılı oldu, HTTP 200 OK dön
	return c.SendStatus(fiber.StatusOK)
}

func listRedisKeys(c *fiber.Ctx) error {
	ctx := context.Background()

	// Tüm anahtarları al
	keys, err := redisClient.Keys(ctx, "*").Result()
	if err != nil {
		return c.Status(500).SendString(err.Error())
	}

	// Anahtarlarla ilişkili değerleri al
	var results []map[string]interface{}
	for _, key := range keys {
		val, err := redisClient.Get(ctx, key).Result()
		if err != nil {
			return c.Status(500).SendString(err.Error())
		}
		data := make(map[string]interface{})
		data[key] = val
		results = append(results, data)
	}

	return c.JSON(results)
}

func main() {
	initPostgres()
	initRedis()

	app := fiber.New()

	app.Post("/task", createTask)
	app.Get("/task/:id", getTask)
	app.Put("/task/:id", updateTask)
	app.Delete("/task/:id", deleteTask)

	// Redis'teki tüm anahtarları ve değerleri listeleyen endpoint
	app.Get("/redis/keys", listRedisKeys)

	// Web sunucusunu başlat
	log.Fatal(app.Listen(":3000"))
}
